import logging
import os
from app.gestor import GestorSistema
from datetime import datetime
from colorama import init, Fore, Style

"""Configuración básica: guarda todo en 'flota.log' con fecha, nivel y mensaje"""
logging.basicConfig(filename="flota.log", level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s", datefmt="%Y-%m-%d %H:%M:%S", encoding="utf-8")

init(autoreset = True)

"""Limpia la consola."""
def clear_screen():
    os.system("cls" if os.name == "nt" else "clear")

"""Comprueba que la fecha tenga formato estricto AAAA-MM-DD y sea válida."""
def validar_fecha(fecha_str):
    try:
        datetime.strptime(fecha_str, "%Y-%m-%d")
        return True
    except ValueError:
        return False


"""Imprime las opciones disponibles en el menú."""
def mostrar_menu():
    print(f"{Fore.CYAN + Style.BRIGHT}  ==============================================")
    print(f"{Fore.CYAN + Style.BRIGHT}     SISTEMA DE GESTIÓN DE FLOTA Y RESERVAS     ")
    print(f"{Fore.CYAN + Style.BRIGHT}  ==============================================")
    print(f"  {Fore.YELLOW + Style.BRIGHT}1.{Style.RESET_ALL} Ver flota completa")
    print(f"  {Fore.YELLOW + Style.BRIGHT}2.{Style.RESET_ALL} Añadir nuevo vehículo")
    print(f"  {Fore.YELLOW + Style.BRIGHT}3.{Style.RESET_ALL} Realizar una reserva")
    print(f"  {Fore.YELLOW + Style.BRIGHT}4.{Style.RESET_ALL} Listar todas las reservas")
    print(f"  {Fore.YELLOW + Style.BRIGHT}5.{Style.RESET_ALL} Salir")
    print(f"{Fore.CYAN + Style.BRIGHT}  ==============================================")

"""Función principal que ejecuta el bucle interactivo del programa."""
def main():
    logging.info("Iniciando el sistema de gestión de flota.")
    gestor = GestorSistema()
    
    while True:
        clear_screen()
        mostrar_menu()

        opcion = input("\nSelecciona una opción (1-5):\n")

        if opcion == "1":
            logging.info("Usuario consultó la flota completa.")
            if not gestor.vehiculos:
                print(f"{Fore.RED}\nNo hay vehículos registrados en la flota.")
            else:
                print(f"{Fore.CYAN + Style.BRIGHT}\n------ FLOTA DE VEHÍCULOS ------\n")
                for v in gestor.vehiculos:
                    print(v)

        elif opcion == "2":
            logging.info("Usuario registró un vehiculo.")
            tipo = input(f"{Fore.CYAN}\nTipo de vehículo (Coche/Moto):\n").strip()
            matricula = input(f"{Fore.CYAN}\nMatrícula:\n{Style.RESET_ALL}").strip()
            modelo = input(f"{Fore.CYAN}\nModelo:\n{Style.RESET_ALL}").strip()

            if not tipo or not matricula or not modelo:
                print(f"{Fore.RED + Style.BRIGHT}\nTodos los campos son obligatorios.\n{Style.RESET_ALL}")
            else:
                motor = input(f"{Fore.CYAN}Motor (pulsa Enter para 'Sin especificar'): ").strip() or "Sin especificar"
                if tipo.lower() == "coche":
                    puertas = input(f"{Fore.CYAN}Número de puertas (pulsa Enter para 'Sin especificar'): ").strip() or "Sin especificar"
                if gestor.añadir_vehiculo(tipo, matricula, modelo, motor, puertas):
                    logging.info(f"Vehículo añadido: {tipo} {modelo} (Matrícula: {matricula})")
                    print(f"\n{Fore.GREEN}{Style.BRIGHT}Vehículo añadido correctamente.\n")
                else:
                    logging.warning(f"Vehiculo no registrado.")
                    print(f"{Fore.RED}{Style.BRIGHT}\nTipo de vehiculo no válido o matrícula ya existente.\n")

        elif opcion == "3":
            matricula = input(f"{Fore.CYAN}\nIntroduzca la matrícula:\n").strip()
            fecha = input(f"{Fore.CYAN}\nIntroduzca la fecha:\n").strip()
            if not matricula or not fecha:
                print(f"{Fore.RED}{Style.BRIGHT}\nLa matrícula y la fecha son obligatorias.\n")
            elif not validar_fecha(fecha):
                print(f"{Fore.RED}{Style.BRIGHT}\nFormato de fecha incorrecto (AAAA-MM-DD)\n")
            elif gestor.reservar_vehiculo(matricula, fecha):
                logging.info(f"Reserva confirmada: Matrícula {matricula} para el {fecha}.")
                print(f"\n{Fore.GREEN}{Style.BRIGHT}Reserva guardada correctamente.\n")
            else:
                logging.warning(f"Reserva rechazada.")
                print(f"{Fore.RED}{Style.BRIGHT}\nNo se pudo realizar la reserva (matrícula inexistente o ya ocupada en esa fecha).\n")

        elif opcion == "4":
            logging.info("Usuario listó todas las reservas.")
            reservas = gestor.reservas            
            if not reservas:
                print("No hay reservas registradas todavía.\n")
            else:
                print(f"{Fore.CYAN}{Style.BRIGHT}\n------ LISTA DE RESERVAS ------\n")
                for i, r in enumerate(reservas, 1):
                    print(f"Matrícula: {r['matricula']} / Fecha: {r['fecha']}")
            pass

        elif opcion == "5":
            logging.info("Cerrando el sistema.")
            clear_screen()
            print(f"{Fore.MAGENTA}{Style.BRIGHT}\nCerrando el sistema. ¡Hasta pronto!\n")
            break

        else:
            print(f"{Fore.RED}{Style.BRIGHT}\nOpción no válida. Introduce un número del 1 al 5.\n")
        input(Style.DIM + "\nPulsa Enter para volver continuar...")

if __name__ == "__main__":
    main()