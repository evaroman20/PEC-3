"""Clase base de vehículo genérico de la flota."""
class Vehiculo():
    def __init__(self, matricula, modelo, motor = "Sin especificar"):
        self.__matricula = matricula.strip().upper()
        self.__modelo = modelo.strip()
        self.__motor = motor

    """Devuelve la matrícula del vehículo."""
    @property 
    def matricula(self):
        return self.__matricula

    """Devuelve el modelo del vehículo."""
    @property
    def modelo(self):
        return self.__modelo

    """Devuelve el motor del vehículo."""
    @property
    def motor(self):
        return self.__motor

    """Devuelve una frase explicativa del vehículo."""
    def __str__(self):
        return f"El vehiculo es {self.__modelo} con motor {self.__motor} y matrícula {self.__matricula}."


"""Subclase de coche dentro de la flota."""
class Coche(Vehiculo):
    def __init__(self, matricula, modelo, motor = "Sin especificar", puertas = "Sin especificar"):
        super().__init__(matricula, modelo, motor)
        self.__puertas = puertas

    """Devuelve el número de puertas del coche."""
    @property
    def puertas(self):
        return self.__puertas

    """Devuelve una frase para explicar Coche."""
    def __str__(self):
        return f"[Coche] modelo {self.modelo}, motor {self.motor}, matrícula {self.matricula} y ({self.puertas} puertas)."


"""Subclase de coche dentro de la flota."""
class Moto(Vehiculo):
    def __init__(self, matricula, modelo, motor = "Sin especificar"):
        super().__init__(matricula, modelo, motor)

    def __str__(self):
        return f"[Moto] modelo {self.modelo}, motor {self.motor} y matrícula {self.matricula}."