from app.vehiculos import Coche, Moto
from app.persistencia import cargar_vehiculos, guardar_vehiculos, cargar_reservas, guardar_reservas


"""Gestiona la flota de vehículos, las reservas y su persistencia."""
class GestorSistema:
    """Inicializa el gestor cargando los datos previos desde los archivos."""
    def __init__(self):
        self.__vehiculos = cargar_vehiculos()
        self.__reservas = cargar_reservas()


    """Devuelve la lista de vehículos registrados."""
    @property
    def vehiculos(self):
        return self.__vehiculos


    """Devuelve la lista de reservas registradas."""
    @property
    def reservas(self):
        return self.__reservas


    """Añade un coche o moto si su matrícula no está duplicada."""
    def añadir_vehiculo(self, tipo, matricula, modelo, motor = "Sin especificar", puertas = "Sin especificar"):
        matricula = matricula.strip().upper()
        for v in self.__vehiculos:
            if v.matricula == matricula:
                return False
        if tipo.lower() == "coche":
            nuevo = Coche(matricula, modelo)
        elif tipo.lower() == "moto":
            nuevo = Moto(matricula, modelo)
        else:
            return False
        self.__vehiculos.append(nuevo)
        guardar_vehiculos(self.__vehiculos)
        return True

    """Valida existencia y disponibilidad para registrar una nueva reserva."""
    def reservar_vehiculo(self, matricula, fecha):
        matricula = matricula.strip().upper()
        fecha = fecha.strip()
        existe = False
        for v in self.__vehiculos:
            if v.matricula == matricula:
                existe = True
                break
        if not existe:
            print("No existe ningún vehículo con esa matrícula.")
            return False
        for r in self.__reservas:
            if r["matricula"] == matricula and r["fecha"] == fecha:
                print("\nEl vehículo ya está reservado en esa fecha.\n")
                return False
        self.__reservas.append({"matricula": matricula, "fecha": fecha})
        guardar_reservas(self.__reservas)
        return True
