from app.vehiculos import Coche, Moto

"""Guarda la lista de objetos Vehiculo en un archivo de texto."""
def guardar_vehiculos(lista_vehiculos, ruta = "vehiculos.txt"):
    with open(ruta, "w", encoding = "utf-8") as archivo:
        for v in lista_vehiculos:
            if isinstance(v, Coche):
                archivo.write(f"\nCoche,{v.matricula},{v.modelo},{v.motor},{v.puertas}\n")
            else:
                archivo.write(f"\nMoto,{v.matricula},{v.modelo},{v.motor}\n")


"""Lee el archivo de texto y devuelve una lista de objetos Coche y Moto."""
def cargar_vehiculos(ruta = "vehiculos.txt"):
    vehiculos = []
    try:
        with open(ruta, "r", encoding = "utf-8") as archivo:
            for linea in archivo:
                linea = linea.strip()
                if linea:
                    datos = linea.split(",")
                    if datos[0] == "Coche":
                        vehiculos.append(Coche(datos[1], datos[2], datos[3], datos[4]))
                    elif datos[0] == "Moto":
                        vehiculos.append(Moto(datos[1], datos[2], datos[3]))
    except FileNotFoundError:
        pass
    return vehiculos

"""Guarda la lista de reservas en un archivo de texto."""
def guardar_reservas(lista_reservas, ruta = "reservas.txt"):
     with open(ruta, "w", encoding = "utf-8") as archivo:
            for reserva in lista_reservas:
                archivo.write(f"{reserva["matricula"]} , {reserva["fecha"]}\n")

"""Lee el archivo de reservas y devuelve una lista de diccionarios."""
def cargar_reservas(ruta = "reservas.txt"):
    reservas = []
    try:
        with open(ruta, "r", encoding = "utf-8") as archivo:
            for linea in archivo:
                linea = linea.strip()
                if linea:
                    matricula, fecha = linea.split(",")
                    reservas.append({"matricula": matricula, "fecha": fecha})
    except FileNotFoundError:
        pass
    return reservas